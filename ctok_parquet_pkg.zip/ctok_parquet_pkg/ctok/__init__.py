"""ctok-parquet: parquet-only training wrapper with schema->text preprocessors."""
